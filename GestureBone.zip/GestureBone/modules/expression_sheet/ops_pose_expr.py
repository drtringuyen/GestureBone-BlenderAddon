"""
expression_sheet/ops_pose_expr.py — Pose-mode expression grid (E key by
default; user-rebindable, since E is unusable on macOS and Alt/Ctrl/Shift+E
are already Blender's keyframe-interpolation hotkeys).

Merged from the standalone PoseExpressionGrid script. Opens the shared sprite
grid in Pose mode and keyframes each selected bone's ``exp_index`` as a
CONSTANT step, so an expression sprite holds until the next keyed change.
Handles Blender <4.4 and 4.4+ layered actions when locating the fcurve.
"""
import bpy

from .grid import _SpriteGridBase
from .props import resolve_grid

_EXP_PROP = "exp_index"   # custom int property on each pose bone


# ── Action / fcurve compatibility (Blender 4.4+ layered Actions) ──────────────
#  (same pattern as GestureBone/modules/shared/utils_bake.py::_get_fcurve_store)

def _get_fcurve_store(arm_obj):
    """F-curve collection for this armature's action (handles <4.4 and 4.4+)."""
    anim = arm_obj.animation_data
    if not anim or not anim.action:
        return None
    action = anim.action
    if hasattr(action, 'fcurves'):
        return action.fcurves
    try:
        slot = getattr(anim, 'action_slot', None)
        if slot is None and action.slots:
            slot = action.slots[0]
        if slot is None:
            return None
        for layer in action.layers:
            for strip in layer.strips:
                for method_name in ('channelbag', 'channelbag_for_slot'):
                    cb_fn = getattr(strip, method_name, None)
                    if cb_fn:
                        try:
                            cb = cb_fn(slot)
                            if cb and hasattr(cb, 'fcurves'):
                                return cb.fcurves
                        except Exception:
                            pass
    except Exception:
        pass
    return None


def _bone_exp_fcurve(arm_obj, bone_name):
    """Find the exp_index fcurve for this bone, or None if never keyed."""
    fcurves = _get_fcurve_store(arm_obj)
    if fcurves is None:
        return None
    data_path = f'pose.bones["{bone_name}"]["{_EXP_PROP}"]'
    return fcurves.find(data_path, index=0)


def _force_constant(fcurve):
    """Set every existing keyframe on this fcurve to CONSTANT interpolation."""
    if fcurve is None:
        return
    for kp in fcurve.keyframe_points:
        kp.interpolation = 'CONSTANT'


def _ensure_exp_index(pose_bone, max_index=None):
    """Ensure pose_bone has the exp_index custom property; return its value.

    Also refreshes the property's UI data (range, default, description) so the
    N-panel slider clamps to the bone's own grid instead of the full int range,
    and marks the property library-overridable so a downstream file that links
    this rig and makes a library override can edit exp_index directly (not just
    through keyframes) and have it stick across a reload.

    docs/expression-bones-design.md previously concluded this was impossible,
    but that testing only tried it through the OWNING OBJECT with the full
    nested path (`ob.property_overridable_library_set('pose.bones["X"]["exp_index"]', ...)`),
    which Blender rejects as "not found". Calling it directly on the PoseBone
    struct with a property path relative to itself (`pose_bone.property_overridable_library_set('["exp_index"]', True)`)
    works. Verified with a full headless round trip (2026-09-07, Blender
    5.2.1 LTS): flagged the property on a source-file bone, linked that
    object into a fresh file, ran Make Library Override, set exp_index to an
    UNKEYED static value on the override, saved, and reopened — the value
    held. The flag on the IDProperty itself is what the override system
    actually keys off; the "not found" path is an RNA path-resolution
    quirk of the two-argument owning-ID form, not evidence the flag can't be
    set at all.
    """
    if _EXP_PROP not in pose_bone.keys():
        pose_bone[_EXP_PROP] = 0
    try:
        pose_bone.property_overridable_library_set('["%s"]' % _EXP_PROP, True)
    except Exception:
        # Refuses on a bone that can't carry the flag (e.g. still resolving on
        # file load) — keying still works regardless, just without the static
        # unkeyed-edit convenience this unlocks.
        pass
    try:
        ui = pose_bone.id_properties_ui(_EXP_PROP)
        # min/soft_min mirror max/soft_max negative: negative values are a real,
        # meaningful mirror-flip flag (see project memory on exp_index), not an
        # error state, so the N-panel slider must not clamp them to 0.
        neg_bound = -max_index if max_index is not None else -(2 ** 31)
        ui.update(min=neg_bound, soft_min=neg_bound, default=0,
                  description="Expression sprite cell index "
                              "(UV order: 0 = bottom-left; negative = mirrored flip)",
                  **({"max": max_index, "soft_max": max_index}
                     if max_index is not None else {}))
    except Exception:
        # id_properties_ui refuses on a linked (non-editable) bone; the value
        # still reads fine, and UI metadata is cosmetic.
        pass
    return int(pose_bone[_EXP_PROP])


def keying_blocked_reason(arm_obj):
    """Why exp_index can't be keyed on *arm_obj*, or None if it can.

    A linked + library-overridden character usually still points at the
    library's own action, which is read-only. Blender then SKIPS keyframe
    insertion with only a console warning ("not editable").

    NOT called by the pickers any more — it used to gate the grid open and
    refused to show it at all on a read-only action, which made E look dead.
    Kept as a diagnostic helper for that case (see
    docs/expression-bones-design.md).
    """
    ad = arm_obj.animation_data
    act = ad.action if ad else None
    if act is None:
        return None                      # no action yet: Blender makes one
    editable = getattr(act, "is_editable", None)
    if editable is None:                 # older Blender: fall back to linkage
        editable = act.library is None
    if not editable:
        return ("Action '%s' is linked and read-only — assign a local action "
                "(Dope Sheet > Action Editor > New) before keying expressions"
                % act.name)
    return None


def _key_expression_change(context, arm_obj, bones, new_idx):
    """Apply *new_idx* to *bones*, keying it on the current frame only.

    One key per bone, on ``frame_current``, nothing else touched. The channel
    is CONSTANT, so a key at frame F already only takes effect from F onward
    and the preceding key holds its own value up to it — the backfill key at
    ``frame - 1`` this used to write bought nothing, and landed a spurious key
    one frame back whenever the playhead sat on an existing key.
    """
    frame = context.scene.frame_current

    for pb in bones:
        _ensure_exp_index(pb, resolve_grid(arm_obj, pb.name, context).max_index)
        pb[_EXP_PROP] = new_idx
        pb.keyframe_insert(data_path=f'["{_EXP_PROP}"]', frame=frame)
        # keyframe_insert can (re)create the fcurve — re-fetch, then normalize.
        _force_constant(_bone_exp_fcurve(arm_obj, pb.name))


# ── Operator ──────────────────────────────────────────────────────────────────

class GESTUREBONE_OT_PoseExpressionGrid(_SpriteGridBase):
    """Open the pose-bone expression grid at the mouse and key the selected bones"""
    bl_idname  = "gesturebone.pose_expression_grid"
    bl_label   = "Pose Expression Grid"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if obj is None or obj.type != 'ARMATURE' or obj.mode != 'POSE':
            return False
        return any(pb.select for pb in obj.pose.bones)

    def _grid_settings(self, context):
        # The ACTIVE bone decides which sheet the grid shows. Multi-select
        # still commits to every selected bone; mixing bones that use
        # different sheets is the user's call, and the active one is the only
        # unambiguous choice of what to draw.
        arm = context.active_object
        active_pb = context.active_pose_bone
        return resolve_grid(arm, active_pb.name if active_pb else "", context)

    def _prepare(self, context):
        arm = context.active_object
        self._arm = arm
        self._bones = [pb for pb in arm.pose.bones if pb.select]
        if not self._bones:
            return False
        # Ensure exp_index exists and its UI range matches each bone's grid.
        # Existing keys are deliberately left alone here — opening the picker
        # (and pressing Esc) must not rewrite curves you never committed to.
        for pb in self._bones:
            _ensure_exp_index(pb, resolve_grid(arm, pb.name, context).max_index)
        return True

    def _seed_chosen(self, context):
        active_pb = context.active_pose_bone
        if not active_pb:
            return -1
        settings = resolve_grid(context.active_object, active_pb.name, context)
        return min(_ensure_exp_index(active_pb, settings.max_index),
                   settings.max_index)

    def _commit(self, context, idx):
        _key_expression_change(context, self._arm, self._bones, idx)


_addon_keymaps = []


def register():
    bpy.utils.register_class(GESTUREBONE_OT_PoseExpressionGrid)

    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name='Pose', space_type='EMPTY')
        kmi = km.keymap_items.new(GESTUREBONE_OT_PoseExpressionGrid.bl_idname, 'E', 'PRESS')
        _addon_keymaps.append((km, kmi))


def unregister():
    for km, kmi in _addon_keymaps:
        km.keymap_items.remove(kmi)
    _addon_keymaps.clear()

    bpy.utils.unregister_class(GESTUREBONE_OT_PoseExpressionGrid)


def get_keymap_item():
    """(km, kmi) for the expression-grid hotkey, editable via the UI, or None.

    Reads back through wm.keyconfigs.user so edits made in the UI (which
    Blender stores as a user override) are reflected immediately.
    """
    if not _addon_keymaps:
        return None
    km_addon, kmi_addon = _addon_keymaps[0]
    wm = bpy.context.window_manager
    km_user = wm.keyconfigs.user.keymaps.get(km_addon.name)
    if km_user is None:
        return None
    for kmi in km_user.keymap_items:
        if kmi.idname == kmi_addon.idname:
            return km_user, kmi
    return None
