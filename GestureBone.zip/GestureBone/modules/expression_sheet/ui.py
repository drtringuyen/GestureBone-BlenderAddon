"""
expression_sheet/ui.py -- single combined "Expression Sheet" panel.

Sections: scene grid defaults, the per-bone expression-bone registry, the
pose-mode expression key hint, and a pointer to the Shader Editor node that
reads exp_index back.
"""
import bpy

from .ops_pose_expr import _EXP_PROP, get_keymap_item
from .props import find_entry


class GESTUREBONE_PT_ExpressionSheet(bpy.types.Panel):
    bl_label       = "Expression Sheet"
    bl_idname      = "GESTUREBONE_PT_expression_sheet"
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = "GestureBone"
    bl_parent_id   = "GESTUREBONE_PT_main"
    bl_order       = 10
    bl_options     = {'DEFAULT_CLOSED'}

    def draw(self, context):
        props  = context.scene.gesturebone_spritesheet
        layout = self.layout

        # -- Scene defaults ------------------------------------------------
        # Fallback for bones with no entry, and the source of the default cell
        # size (a monitor-dependent viewing preference, so it stays scene-level
        # rather than being baked into the rig).
        col = layout.column(align=True)
        col.label(text="Sheet Defaults", icon='IMGDISPLAY')
        row = col.row(align=True)
        row.prop(props, "grid_size")
        row.prop(props, "grid_count")
        self._draw_sheet_row(col, props, "sheet_image", "Sheet", -1)
        self._draw_sheet_row(col, props, "flip_sheet_image", "Flip Sheet", -1)

        layout.separator()

        self._draw_expression_bones(context, layout)

        layout.separator()

        # -- Pose-mode expression grid ------------------------------------
        col = layout.column(align=True)
        col.label(text="Pose Expression", icon='POSE_HLT')

        found = get_keymap_item()
        if found:
            _, kmi = found
            row = col.row(align=True)
            row.label(text="Hotkey (Pose Mode):")
            row.prop(kmi, "type", text="", full_event=True)
        else:
            col.label(text="Press E in Pose Mode to open the grid", icon='INFO')

        layout.separator()

        # -- Shader node pointer -------------------------------------------
        col = layout.column(align=True)
        col.label(text="Shader Editor > Add:", icon='NODETREE')
        col.label(text="- UV From Bone (Shared)", icon='UV')

    # -- One Sheet / Flip Sheet field, fixed proportions -------------------

    def _draw_sheet_row(self, layout, data, field, label, entry_index):
        """label 20% / image field fills / icon-only fake-user+Open buttons —
        the same template for Sheet Defaults and every per-bone entry.

        Built by hand rather than via ``template_ID(open=...)``: that widget
        only draws Open as an icon once an image is already assigned — with
        nothing assigned yet it draws a wide "Open" text button instead,
        which breaks a fixed layout that has to look the same in both states.
        ``gesturebone.expression_image_open`` (ops_expr_bones.py) is the same
        load-and-assign behavior as an icon-only button.
        """
        row = layout.row(align=True)
        label_split = row.split(factor=0.2, align=True)
        label_split.label(text=label)
        rest = label_split.row(align=True)
        rest.prop(data, field, text="")

        # One ui_unit per icon button, so the cluster is exactly as wide as it
        # draws and ends flush with the row: a percentage-split button column
        # is wider than the icons, and the leftover trails off the right edge.
        # The field takes whatever is left, so the Open icon stays right-
        # aligned across rows whether or not the shield is there.
        img = getattr(data, field)
        btn_row = rest.row(align=True)
        btn_row.ui_units_x = 2.0 if img is not None else 1.0
        if img is not None:
            # Always the OFF icon: ``use_fake_user`` is registered with
            # consecutive icons, so Blender itself draws FAKE_USER_ON when the
            # value is set. Passing FAKE_USER_ON here would make it draw the
            # icon *after* that one in the enum instead of the checked shield.
            btn_row.prop(img, "use_fake_user", text="", icon='FAKE_USER_OFF')
        op = btn_row.operator("gesturebone.expression_image_open", text="",
                              icon='FILEBROWSER')
        op.field = field
        op.entry_index = entry_index

    # -- Expression bone registry ------------------------------------------

    def _draw_expression_bones(self, context, layout):
        arm = context.active_object
        header = layout.row(align=True)
        header.label(text="Expression Bones", icon='BONE_DATA')

        if arm is None or arm.type != 'ARMATURE':
            layout.label(text="Select an armature", icon='INFO')
            return

        header.operator("gesturebone.expression_bone_add", text="", icon='ADD')
        header.operator("gesturebone.expression_bone_sync", text="",
                        icon='FILE_REFRESH')

        entries = arm.gesturebone_props.expression_bones
        if not entries:
            layout.label(text="Select bones in Pose mode, then +", icon='INFO')
            return

        # exp_index is flagged library-overridable by _ensure_exp_index (see
        # ops_pose_expr.py) the first time Add/Sync/the E-grid/the Cell picker
        # touches a bone, so a typed edit sticks across reload from then on.
        # A bone this session hasn't touched yet (a very old entry, before
        # this flag existed, on a file that hasn't run Sync since) may not
        # have it set — nudge toward Sync rather than let a typed edit quietly
        # disappear on reload in that one remaining case.
        if arm.override_library is not None:
            warn = layout.box().column(align=True)
            warn.label(text="Linked override: run Sync once if a typed",
                       icon='INFO')
            warn.label(text="edit doesn't stick after reload.")

        for i, entry in enumerate(entries):
            pb = arm.pose.bones.get(entry.bone)
            box = layout.box()

            row = box.row(align=True)
            row.prop(entry, "ui_expanded", text="",
                     icon='TRIA_DOWN' if entry.ui_expanded else 'TRIA_RIGHT',
                     emboss=False)

            name_sub = row.row(align=True)
            name_sub.alert = pb is None          # bone renamed or deleted
            name_sub.label(text=entry.bone or "(unset)",
                           icon='BONE_DATA' if pb else 'ERROR')

            # The live custom property, not a copy: this is the value the
            # shader-node drivers read, and drawing it directly keeps one
            # source of truth (and puts right-click > Insert Keyframe on it).
            # Width-capped so the bone name keeps the rest of the row — in a
            # default-width sidebar an uncapped field truncates it to "EXP-...",
            # which is the one thing the header has to be readable.
            if pb is not None and _EXP_PROP in pb.keys():
                idx_sub = row.row(align=True)
                idx_sub.ui_units_x = 3.0
                idx_sub.prop(pb, '["%s"]' % _EXP_PROP, text="")
            else:
                row.label(text="no index")

            rm = row.operator("gesturebone.expression_bone_remove", text="",
                              icon='X')
            rm.index = i

            if not entry.ui_expanded:
                continue

            body = box.column(align=True)
            if pb is None:
                body.label(text="Bone missing — rename or re-sync", icon='ERROR')

            self._draw_sheet_row(body, entry, "sheet_image", "Sheet", i)
            self._draw_sheet_row(body, entry, "flip_sheet_image", "Flip Sheet", i)
            # Cell Size left, Grid Count right — same order as Sheet Defaults.
            grid_row = body.row(align=True)
            grid_row.prop(entry, "grid_size")
            grid_row.prop(entry, "grid_count")

            # Reordering is cosmetic (nothing reads the list order), so the
            # arrows live down here rather than competing with the bone name.
            bottom = body.row(align=True)
            pick = bottom.row(align=True)
            pick.enabled = pb is not None
            op = pick.operator(
                "gesturebone.expression_cell_pick",
                text="Cell %s" % (pb.get(_EXP_PROP, 0) if pb else "-"),
                icon='SNAP_VERTEX',
            )
            op.bone = entry.bone

            if len(entries) > 1:
                move = bottom.row(align=True)
                move.ui_units_x = 2.0
                up = move.operator("gesturebone.expression_bone_move", text="",
                                   icon='TRIA_UP')
                up.index, up.direction = i, 'UP'
                dn = move.operator("gesturebone.expression_bone_move", text="",
                                   icon='TRIA_DOWN')
                dn.index, dn.direction = i, 'DOWN'


class GESTUREBONE_PT_ExpressionSheetNodeTools(bpy.types.Panel):
    bl_label       = "Expression Sheet"
    bl_idname      = "GESTUREBONE_PT_expression_sheet_node_tools"
    bl_space_type  = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category    = "GestureBone"

    @classmethod
    def poll(cls, context):
        space = context.space_data
        return space.tree_type == 'ShaderNodeTree'

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)

        tree = context.space_data.edit_tree
        node = tree.nodes.active if tree is not None else None

        if node is None or node.bl_idname != "ShaderNodeCustomUVFromBoneShared":
            col.label(text="Select a 'UV From Bone (Shared)' node", icon='INFO')
            return

        col.label(text=node.name, icon='UV')
        col.operator("gesturebone.tidy_expression_node_driver", icon='SORTALPHA')


def register():
    bpy.utils.register_class(GESTUREBONE_PT_ExpressionSheet)
    bpy.utils.register_class(GESTUREBONE_PT_ExpressionSheetNodeTools)


def unregister():
    bpy.utils.unregister_class(GESTUREBONE_PT_ExpressionSheetNodeTools)
    bpy.utils.unregister_class(GESTUREBONE_PT_ExpressionSheet)
